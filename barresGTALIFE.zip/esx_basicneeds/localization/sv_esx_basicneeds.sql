USE `essentialmode`;

INSERT INTO `items` (`name`, `label`, `limit`) VALUES
	('bread', 'Bröd', 10),
	('water', 'Vatten', 5)
;